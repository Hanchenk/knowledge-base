# DSH Team Coordinate Plugin

这是面向 DSH Desktop 的内网项目协作插件，当前版本 `0.1.0-alpha.20`。

`alpha.20` 加入知小汇双向同步：无需先登录 Team Hub，插件登录页和团队项目页均可打开「连接知小汇」。在知小汇网页「云端 → 连接本地」生成十分钟配对码，输入服务器地址并选择一个 Harness 工作区后，该工作区的已有会话和新会话自动同步到配对账号。网页选择此设备后，任务使用桌面端的原生模型、工具、会话和上下文压缩机制执行，公开回复、工具名称、步骤和文本成果回传网页。不会启动第二个独立 Harness 进程。

此功能要求官方 DeepSeek Harness Desktop **0.2.0-rc.2**（此版本已验证）。本地发起的每一轮对话会成为一个知小汇任务，同一会话中的后续轮次保留对话关联；网页继续对话沿用原生会话。断线时原生执行继续，公开消息、步骤和成果通过持久化队列补传；重复派发由原生 `requestId` / `source.rpcId` 去重。设备离线时网页任务等待该设备，不自动改为云端执行。任务取消回传桌面端，账号停用或设备解除连接后拒绝后续上传。

同步仅包含用户输入和助手可见文字、工具名称与成功状态；不上传隐藏推理、工具参数/原始结果或模型密钥。平台知识库通过 `zhixiaohui_knowledge_*` 工具按当前账号和任务授权读取，`zhixiaohui_task_plan` 更新网页步骤，`zhixiaohui_write_artifact` 先保存本地文件再同步文本成果（md/txt/csv/json/py，每个最多 300KB）。桌面端的其他本地文件不会自动上传；原生操作审批仍在桌面端处理。平台应用连接器用于云端任务，本地任务使用桌面端已安装的应用工具。

设备专用可撤销凭据和待上传记录存放在当前 profile 的插件数据目录下 `zhixiaohui.sqlite`（权限 600），成果在同目录 `artifacts` 子目录。此凭据只允许访问该设备的任务，不能用于平台通用 REST/MCP API。公网服务器使用 HTTPS；沿用当前平台的可信内网 HTTP 部署。

安装包：`dsh-plugin-team-hub-0.1.0-alpha.20.tgz`。通过官方桌面端插件页安装后重启生效，或运行 `dsh plugin --profile desktop add /absolute/path/dsh-plugin-team-hub-0.1.0-alpha.20.tgz`。升级前保留旧包以便回退。真实官方运行时测试使用隔离测试工作区和模拟模型，不代表已验证 Electron GUI 安装流程或真实模型研究质量。

`alpha.19` 平台成员目录可以直接拉人进项目：对「尚未创建团队账号」的成员，卡片上新增项目角色选择与「创建账号并加入」按钮，先调用 Hub 的 `POST /team/v1/users` 建立本地账号（账号名取平台登录名/邮箱前缀，非法字符自动替换，重名或不可用时回退到 `u<平台ID>`），再调用 `POST /team/v1/projects/<id>/members` 加入项目，成功后弹窗给出账号名与初始密码，由管理员转告本人；对方首次登录后可自行修改密码。同时把成员页在无可添加账号时的提示从「全部用户已在项目中」改为指向平台成员区。该路径不依赖服务端改动，也不依赖野马通行证 SSO 在线。

`alpha.18` 修复平台成员区的「重新同步」按钮：`icon-only` 按钮此前只在 `header` 内隐藏标签，整页宽度下按钮被压成 36px 宽、文字竖排并挤到内容最右侧；现在 `icon-only` 在所有作用域都只显示图标（标签保留在 `title`/`aria-label`），面板内统一为与工具栏一致的圆形按钮。

`alpha.17` 把界面从右下角浮动面板改为 Harness 的标准页面模型：左侧栏新增「团队项目」面板图标（`sidebar.panellist`），点击后在主区域打开整页（`main` 槽位，key 与图标 id 同为 `team-hub`），与官方「插件」「定时任务」页一致，不再遮挡对话内容。页面内仍是原有插件界面，通过 `/team-plugin/` 内嵌展示。选择任意会话即可返回对话。浮动面板、拖拽缩放和侧栏底部入口已移除。

`alpha.16` 适配 DSH `0.2.0-rc.1` 及以上的 Desktop profile：宿主半侧改为按新的 `profileContext` 服务解析 profile 目录（旧的 `desktopProfiles` 仍兼容），自动更新改用 `profileContext.packageManager` 调用内置 pnpm。旧版在最新桌面端注入的 `desktopProfiles` 已不存在，宿主 fiber 一直停留在 `pending`，`/team-plugin` 路由未注册，面板因此白屏；本版修复该问题。升级后需要重启 Desktop 生效。

`alpha.11` 新增内网签名包自动更新：登录后记住 Hub 地址，每 30 分钟检查版本，通过 Desktop 原生安装器安装新包，重启 Desktop 后生效。面板顶部“插件更新”可查看状态、立即检查或关闭自动更新。旧版须手动安装本版一次，发布说明见 Hub 仓库 `docs/plugin-auto-update.md`。

`alpha.10` 新增项目工作台：动态、计划看板、任务、共享资产、项目指令、46 个 WorkBuddy 专家团目录和服务器周期自动化。部署方式及功能边界见 Hub 仓库 `docs/workbuddy-integration.md`。

`alpha.9` 使用适配浅色/深色主题的半透明玻璃浮动面板。项目管理项收进独立菜单，功能导航显示图标与名称；固定外框与独立内容滚动区避免切换内容时尺寸变化。

`alpha.8` 新增服务器常驻 AgentTeams 协作、Agent 项目成员、多 GitLab 仓库、任务计划批准和执行状态面板。部署与运行边界见 Hub 仓库 `docs/agent-teams.md`。

`alpha.7` 修复预设挂载返回值导致的 `commit is not a function`。复用上下文只写入此次创建的会话；后续普通新会话不继承。项目记忆继续同步和按需检索，但不再自动注入每个会话的系统提示词。已存在会话的历史记录不自动删除。

此版本修复复用会话成功后工作区不显示的问题：在 Agent 创建前导入完整的已结束轮次，保留默认模型和 Agent 预设，保存工作区归属及会话标题后再提示成功。历史内容仍作为 recall 上下文导入，不执行原会话工具调用。升级后重新点击复用即可，旧版本创建的隐藏会话不会自动修改。

支持内网 HTTP 登录、项目创建与邀请、项目成员管理、本地会话/目录绑定、对话增量采集、记忆自动同步、会话内复用和 `team_memory_search` / `team_memory_read` 工具。可信内网试点可以使用 HTTP，登录使用 Hub 账号密码。

模型整理由配套 Hub 服务统一执行，自动发布，无需审核。插件不收集个人模型 API 密钥。选择并关联项目工作区后，该目录中的已有会话与后续新会话自动同步。同步用户和助手的可见文本，保留全部文本分片，不上传隐藏推理、工具执行状态、附件二进制或个人模型凭据。

## 安装

本包需要支持 `node:sqlite` 的 Node.js 22.19+，以及提供 `webServer`、`sessions` 的 Desktop profile；profile 目录与内置 pnpm 从 `profileContext`（DSH `0.2.0-rc.1` 及以上）或旧的 `desktopProfiles` / `desktopPnpm`（DSH `0.1.2-rc.1`）读取，两者都不存在时无法启动。`systemPrompt`、`tools`、`sessionQuery`、`workspaceRegistry` 可选，没有对应服务时界面仍可用。

使用 Desktop 标准插件管理入口安装此精确版本或本地 `.tgz` 包。使用该 Desktop 配套的 DSH CLI 时，可在当前 profile 下运行：

```sh
dsh plugin add /absolute/path/dsh-plugin-team-hub-0.1.0-alpha.19.tgz --profile <当前profile名称>
```

重启 Desktop，点击左侧栏的「团队项目」图标（与「插件」「定时任务」同排）在主区域打开页面。登录后选择项目，在弹窗中选择已有工作区或输入绝对目录路径新建工作区。项目经理、技术总监在成员页直接添加用户，无需邀请令牌或接受邀请。

页面占据主区域，与对话互斥：点击左侧栏任意会话即可回到对话。页面内保留原有功能导航与滚动区，宽度随窗口自适应。

配色使用 DeepSeek Harness 的 `--dsw-*` 主题变量；面板内页同步宿主的浅色/深色主题与自定义颜色。未提供主题变量时使用 Harness 默认配色。独立 Hub 管理页面不受插件主题影响。

如果目标安装器只接受 npm 名称，将包上传公司内网 npm 仓库后安装 `dsh-plugin-team-hub@0.1.0-alpha.19`。不要安装到与 Desktop 无关的全局 DSH profile。

## 行为与限制

- 每 2 秒同步；本地 SQLite 保存队列、来源位置和缓存，网络故障后使用相同操作 ID 重试。
- 数据存放在 `~/.dsh-team-plugin/<当前profile目录哈希>/team.sqlite`，不写入 Desktop 管理的 profile 镜像。可通过插件配置的绝对 `dataDir` 覆盖；移动 profile 目录时需要一并迁移该插件数据目录。
- 长期凭据不落盘。关闭 Desktop/profile 或插件卸载后需要重新登录；重登后先重新验证项目权限，再加载记忆。
- 仅采集用户输入和助手可见文本；不采集隐藏推理、插件上下文、工具结果和附件。长文本按 12,000 字符分片上传。
- 缓存最多离线使用 24 小时；登录失效或项目撤权后停止检索。项目记忆通过项目内检索工具按需读取，不自动写入普通新会话。
- 本地队列上限 200 批；满载时保留分片位置，待队列恢复后继续上传，不跳过未上传内容。
- 会话摘要页展示原始文本记录及模型摘要。点击“复用会话”并选择目标工作区后，创建自己的持久化会话，将完整记录作为 Harness recall 上下文导入；来源作者、项目和云端会话 ID 保留。该操作不会自动执行模型或工具，可从工作区中的“复用 · 标题”会话继续提问。
- 已完成真实 Cordis 的插件加载/卸载测试、DSH Client ModuleLoader 格式检查及浏览器插件界面联调。**尚未在真实打包的 Electron Desktop 中完成安装、三种呈现模式和 macOS/Windows 双平台验证，因此当前属于 Alpha 试用包。**

服务端部署、模型配置及本轮未实现项见 Hub 仓库 `docs/team-collaboration.md`。
